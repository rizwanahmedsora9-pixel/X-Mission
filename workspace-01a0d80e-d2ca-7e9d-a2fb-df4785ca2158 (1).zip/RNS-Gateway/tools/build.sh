#!/bin/sh
set -e
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
cd "$ROOT"
mkdir -p module/rns/bin

echo "compile listeners"
gcc -Os -s -o module/rns/bin/rns-httpd-x86_64 src/rns-httpd.c
# HOT 8 is arm64. Android 5+ rejects non-PIE dynamic binaries; static-pie is
# loaded by the kernel. 32-bit static-pie is not available in this toolchain.
aarch64-linux-gnu-gcc -static-pie -Os -s -o module/rns/bin/rns-httpd-arm64 src/rns-httpd.c
arm-linux-gnueabihf-gcc -static -Os -s -o module/rns/bin/rns-httpd-arm src/rns-httpd.c
chmod 755 module/rns/bin/rns-httpd-* module/rns/bin/*.sh module/*.sh 2>/dev/null || true

echo "zip"
rm -f RNS_Gateway.zip
(
  cd module
  zip -r -X ../RNS_Gateway.zip \
    module.prop service.sh post-fs-data.sh uninstall.sh action.sh OPERATOR.txt \
    rns/bin rns/www \
    -x 'rns/bin/rns-httpd-x86_64'
)
# Phone zip should include arm binaries, not the lab x86 binary.
# Rebuild including arm only — the command above excluded x86. Good.
unzip -l RNS_Gateway.zip
echo "built $ROOT/RNS_Gateway.zip"
